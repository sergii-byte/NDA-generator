# Flash NDA Generator — Deployment Instructions

## Структура проекта

```
nda-netlify/
├── index.html              # Главная страница
├── package.json            # Зависимости
├── netlify.toml           # Конфигурация Netlify
└── netlify/
    └── functions/
        ├── generate-nda.js     # Генерация NDA (Claude API)
        ├── parse-company.js    # Парсинг сайта компании
        ├── parse-card.js       # Парсинг визиток
        └── search-company.js   # Поиск в реестрах компаний
```

## Инструкция по развёртыванию на Netlify

### Шаг 1: Создайте аккаунт на Netlify
Зайдите на https://app.netlify.com и зарегистрируйтесь (можно через GitHub).

### Шаг 2: Подключите проект

**Вариант A: Через GitHub (рекомендуется)**
1. Загрузите содержимое папки `nda-netlify` в новый GitHub-репозиторий
2. В Netlify нажмите "Add new site" → "Import an existing project"
3. Выберите ваш репозиторий
4. Netlify автоматически найдёт настройки из `netlify.toml`

**Вариант B: Через Netlify CLI**
```bash
npm install -g netlify-cli
cd nda-netlify
netlify deploy --prod
```

### Шаг 3: Добавьте API-ключи

1. В панели Netlify откройте ваш сайт
2. Перейдите в **Site settings** → **Environment variables**
3. Добавьте переменные:

| Ключ | Обязательный | Описание |
|------|--------------|----------|
| `ANTHROPIC_API_KEY` | ✅ **Да** | Ключ от https://console.anthropic.com |
| `COMPANIES_HOUSE_API_KEY` | ⭐ Рекомендуется | **Бесплатный!** Для поиска UK компаний с полными адресами. Получить: https://developer.company-information.service.gov.uk/ |

> **Примечание:** Без `COMPANIES_HOUSE_API_KEY` поиск UK компаний всё равно работает через OpenCorporates, но с менее полными данными.

### Шаг 4: Пересоберите сайт

После добавления переменных:
1. Перейдите в **Deploys**
2. Нажмите **Trigger deploy** → **Deploy site**

### Шаг 5: Готово!

Ваш сайт доступен по адресу вида:
`https://your-site-name.netlify.app`

## Функции автозаполнения

### 🔍 Поиск по названию компании
Начните вводить название — система предложит варианты из реестров:
- **UK Companies House** — все UK компании с полными адресами
- **OpenCorporates** — 140+ стран мира

### 🔗 Парсинг сайта
Введите URL сайта компании — система проверит главную страницу и /contact для извлечения:
- Юридическое название
- Зарегистрированный адрес  
- Контактный email

### 📇 Парсинг визитки
Загрузите фото визитки — AI извлечёт данные автоматически.

## Лимиты

- **Netlify Free tier:** 125,000 вызовов функций в месяц
- **Anthropic API:** Платите за использование (~$3 за 1M токенов)
- **OpenCorporates:** ~500 запросов/месяц бесплатно
- **UK Companies House:** Бесплатно, без лимитов для зарегистрированных пользователей
